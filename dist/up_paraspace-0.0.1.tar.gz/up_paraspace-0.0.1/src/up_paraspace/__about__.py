# SPDX-FileCopyrightText: 2023-present Bjørnar Luteberget <bjornar.luteberget@sintef.no>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.1"
